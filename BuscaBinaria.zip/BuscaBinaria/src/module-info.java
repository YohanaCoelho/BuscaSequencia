/**
 * 
 */
/**
 * 
 */
module BuscaBinaria {
}