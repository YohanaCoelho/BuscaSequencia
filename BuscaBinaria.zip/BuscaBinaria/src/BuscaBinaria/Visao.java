package BuscaBinaria;

public class Visao {
public static void main(int numeroParaEncontrar, int resultado) {
    if (resultado == -1) {
        System.out.println("Elemento: " + numeroParaEncontrar + " não encontrado");
    } else {
        System.out.println("Elemento: " + numeroParaEncontrar + " encontrado no índice: " + resultado);
    }
}

public static void mostrarResultado(int numeroParaEncontrar, int resultado) {
	// TODO Auto-generated method stub
	
}
}