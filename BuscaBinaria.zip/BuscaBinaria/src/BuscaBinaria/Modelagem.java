package BuscaBinaria;

public class Modelagem {
	// Método para executar a busca binária em um array ordenado
	    public static int buscaBinaria(int array[], int elemento) {
	        int inicio = 0;
	        int fim = array.length - 1;
	     // Loop enquanto o intervalo de busca não estiver vazio
	        while (inicio <= fim) {
	            int meio = (inicio + fim) / 2;
	            if (array[meio] == elemento) {
	                return meio;
	            }
	            if (array[meio] < elemento) {
	                inicio = meio + 1;
	            } else {
	                fim = meio - 1;
	            }
	        }
	        return -1;// Retorna -1 se o elemento não for encontrado no array
	    }
	
}
