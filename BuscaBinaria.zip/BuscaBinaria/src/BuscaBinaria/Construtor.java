package BuscaBinaria;

import java.util.Arrays;

public class Construtor {
	public static void main(String[] args) {
        int[] array = {54, 26, 93, 17, 77, 31, 44, 55, 20, 65};
        Arrays.sort(array);
        System.out.println("Array ordenado: " + Arrays.toString(array));
        int numeroParaEncontrar = 31;
        int resultado = Modelagem.buscaBinaria(array, numeroParaEncontrar);
        Visao.mostrarResultado(numeroParaEncontrar, resultado);
    }
	 
}
